"""SQS → vocal-analysis-worker ECS task (RunTask). Handler: vocal.handler"""

from __future__ import annotations

import json
import os
import traceback

from ecs_run_task import run_worker_task


def handler(event, context):
    batch_failures = []
    for record in event.get("Records", []):
        mid = record.get("messageId") or ""
        try:
            body = json.loads(record["body"])
            if isinstance(body.get("Message"), str):
                body = json.loads(body["Message"])

            job_id = body.get("job_id") or body.get("id")
            if not job_id:
                raise ValueError("SQS body missing job_id")

            env = {"JOB_ID": str(job_id)}
            sk = body.get("s3_key") or body.get("audio_s3_key")
            if sk:
                env["S3_KEY"] = str(sk)

            run_worker_task(
                task_definition=os.environ["ECS_TASK_DEFINITION"],
                container_name=os.environ["ECS_CONTAINER_NAME"],
                environment=env,
            )
        except Exception:
            traceback.print_exc()
            batch_failures.append({"itemIdentifier": mid})
    return {"batchItemFailures": batch_failures}
